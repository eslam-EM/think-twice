// https://docs.expo.dev/guides/using-eslint/
const { defineConfig } = require('eslint/config');
const expoConfig = require("eslint-config-expo/flat");

module.exports = defineConfig([
  expoConfig,
  {
    files: ["scripts/**/*.js", "plugins/**/*.js"],
    languageOptions: { globals: { __dirname: "readonly", require: "readonly", module: "writable", process: "readonly", console: "readonly" } },
  },
  {
    ignores: ["dist/*", "android/*", "output/*", "web-build/*", ".asset-tmp/*"],
  }
]);
